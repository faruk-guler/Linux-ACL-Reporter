
TR:

linux-sysprep
=======================
2 .sh komut dosyası içerir.
RİSK: Komutları çalıştırmadan önce bir yedeğiniz olduğundan emin olun!!
RİSK: Komutları çalıştırmadan önce kesinlikle emin olun!!
'linux-sysprep.sh' benzer bir amaç için kullanılması amaçlanan küçük bir kabuk betiğidir.
Windows sistem yöneticileri tarafından kullanılan 'sysprep' aracının amacı. Çalıştırılacak
tüm sisteme özel yapılandırma verilerini kaldırın ve
diğer ana bilgisayarlarda sağlanan bir görüntü olarak kullanılmaya hazır.

Bu betiği çalıştırmak, sistemi bir sonraki sefere kadar çoğunlukla kullanılamaz hale getirir.
önyükleme yapar, bu nedenle sistemi çalıştırdıktan sonra kapatmanız şiddetle tavsiye edilir.
O IS.

Sorumluluk Reddi: Şu anda bu komut dosyası yalnızca RHEL7'de kullanım için test edilmiştir.
oVirt sanallaştırma ortamının üzerinde sağlanan sistemler. muhtemelen
benzer CentOS ve Fedora sistemlerinde iyi çalışacaktır. Ayrıca olmayacak
diğer Linux sistemlerinde patlayabilir ancak istenen sonucu elde edemeyebilir.
işlevsellik.

Diğer Linux sürümleriyle uyumluluğu geliştirmeye yönelik yamalar memnuniyetle karşılanmaktadır!





EN:
linux-sysprep
=======================
Contains 2 .sh scripts.
RISK: Make sure you have a backup before executing commands!!
RISK: Be absolutely sure before executing commands!!
'linux-sysprep.sh' is a small shell script intended to be used for a similar purpose.
Purpose of the 'sysprep' tool used by Windows system administrators. It is to be run
remove all system specific configuration data and
ready to be used as an image provided on other hosts.

Running this script makes a system mostly unusable until the next time.
it boots, so it is highly recommended to shut down the system after running it.
HE IS.

Disclaimer: Currently this script is only tested for use on RHEL7.
Systems provisioned above the oVirt virtualization environment. probably
it will work fine on similar CentOS and Fedora systems. Also it won't be
on other Linux systems it may explode but not achieve the desired result.
functionality.

Patches to improve compatibility with other Linux versions are welcome!